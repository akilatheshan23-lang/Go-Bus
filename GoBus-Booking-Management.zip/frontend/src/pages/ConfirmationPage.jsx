import React,{useEffect,useState} from 'react'
import { useParams } from 'react-router-dom'
import { api } from '../api'
export default function ConfirmationPage(){
  const { bookingId }=useParams();const [booking,setBooking]=useState(null)
  useEffect(()=>{api.get(`/api/bookings/${bookingId}`).then(r=>setBooking(r.data))},[bookingId])
  if(!booking)return <div>Loading...</div>
  return (<div><h2>Confirmation</h2><div className="card">
    <p><b>Passenger:</b> {booking.passenger?.name} ({booking.passenger?.nic})</p>
    <p><b>Seats:</b> {booking.seats.join(', ')}</p><p><b>Total (incl 10% handling):</b> LKR {booking.total}</p>
    <p>Your booking draft is saved. Payment flow can be connected next.</p></div></div>)
}

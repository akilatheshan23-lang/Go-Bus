import React,{useEffect,useState} from 'react'
import { useNavigate } from 'react-router-dom'
import { api } from '../api'
import Seat from '../components/Seat.jsx'
import Legend from '../components/Legend.jsx'
export default function SeatMapPage(){
  const [trip,setTrip]=useState(null);const [seats,setSeats]=useState([]);const [selected,setSelected]=useState([]);const [baseFare,setBaseFare]=useState(0);const [error,setError]=useState('')
  const nav=useNavigate()
  useEffect(()=>{async function load(){setError('');const demo=await api.get('/api/trips/demo');const id=demo.data.trip._id;const res=await api.get(`/api/trips/${id}/seats`);setTrip({id});setSeats(res.data.seats);setBaseFare(res.data.base_fare);}load().catch(e=>setError(e.response?.data?.error||e.message))},[])
  const toggle=(n)=>{const s=seats.find(x=>x.number===n);if(s.status!=='available')return;setSelected(p=>p.includes(n)?p.filter(i=>i!==n):[...p,n])}
  const proceed=async()=>{const res=await api.post('/api/bookings',{tripId:trip.id,seats:selected});const id=res.data.bookingId;sessionStorage.setItem(`hold-${id}`,res.data.expiresAt);nav(`/passenger/${id}`)}
  return (<div><h2>Select your seats</h2><Legend/>{error&&<div className="card" style={{color:'crimson'}}>{error}</div>}
    <div className="seat-grid" role="grid" aria-label="Seat map">{seats.map(seat=>(<Seat key={seat.number} seat={seat} isSelected={selected.includes(seat.number)} onClick={()=>toggle(seat.number)}/>))}</div>
    <div className="card"><p>Unit fare: LKR {baseFare}</p><p>Selected: {selected.join(', ')||'None'}</p><button className="btn" disabled={selected.length===0} onClick={proceed}>Proceed</button></div>
  </div>)}

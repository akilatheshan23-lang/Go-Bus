import React,{useEffect,useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../api'
import CountdownTimer from '../components/CountdownTimer.jsx'
export default function PassengerDetailsPage(){
  const { bookingId }=useParams();const [booking,setBooking]=useState(null);const [expiresAt,setExpiresAt]=useState(null);const nav=useNavigate()
  useEffect(()=>{async function load(){const b=await api.get(`/api/bookings/${bookingId}`);setBooking(b.data);const local=sessionStorage.getItem(`hold-${bookingId}`);setExpiresAt(local||new Date(Date.now()+5*60*1000).toISOString())}load().catch(console.error)},[bookingId])
  const submit=async(e)=>{e.preventDefault();const form=new FormData(e.target);const payload=Object.fromEntries(form.entries());await api.patch(`/api/bookings/${bookingId}/passenger`,payload);nav(`/confirm/${bookingId}`)}
  if(!booking)return <div>Loading...</div>
  const { seats, amount_base, handling_fee, total }=booking
  return (<div><h2>Passenger details</h2>
    <div className="card"><p><b>Seats:</b> {seats.join(', ')}</p><p><b>Hold expires in:</b> <CountdownTimer expiresAt={expiresAt}/></p><p><b>Fare:</b> Base LKR {amount_base} + Handling (10%) LKR {handling_fee} = <b>LKR {total}</b></p></div>
    <form className="card" onSubmit={submit}><div className="grid2">
      <input className="input" name="name" placeholder="Full name" required /><input className="input" name="nic" placeholder="NIC / ID" required />
      <input className="input" name="phone" placeholder="Phone" required /><input className="input" name="email" placeholder="Email" type="email" required /></div>
      <textarea className="input" name="special_needs" placeholder="Special needs (optional)" style={{marginTop:12}} />
      <div style={{marginTop:12,display:'flex',gap:12}}><button className="btn" type="submit">Save & Continue</button></div>
    </form></div>)
}

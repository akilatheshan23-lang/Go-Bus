import React,{useEffect,useState} from 'react'
export default function CountdownTimer({expiresAt}){
  const [left,setLeft]=useState(0)
  useEffect(()=>{const id=setInterval(()=>{const ms=Math.max(0,new Date(expiresAt).getTime()-Date.now());setLeft(ms)},250);return()=>clearInterval(id)},[expiresAt])
  const sec=Math.round(left/1000);const mm=String(Math.floor(sec/60)).padStart(2,'0');const ss=String(sec%60).padStart(2,'0')
  return <span className="timer">{mm}:{ss}</span>
}

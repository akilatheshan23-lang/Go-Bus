import React from 'react'
export default function Legend(){return (<div className="legend">
  <span><div className="seat available" style={{width:18,height:18}}/> Available</span>
  <span><div className="seat selected" style={{width:18,height:18}}/> Selected</span>
  <span><div className="seat held" style={{width:18,height:18}}/> Held</span>
  <span><div className="seat booked" style={{width:18,height:18}}/> Reserved</span>
  <span><div className="badge">W</div> Window</span>
</div>)}

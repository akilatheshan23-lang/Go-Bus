import React from 'react'
export default function Seat({ seat, isSelected, onClick }){
  const cls=['seat', seat.status, isSelected?'selected':''].join(' ')
  return (<div className={cls} onClick={onClick} aria-label={`Seat ${seat.number} ${seat.type==='W'?'window':''} ${seat.status}`}>
    {seat.number}{seat.type==='W' && <span className="badge">W</span>}
  </div>)
}

import express from 'express';import morgan from 'morgan';import cors from 'cors';import dotenv from 'dotenv';import http from 'http';
import { connectDB } from './config/db.js';import tripsRouter from './routes/trips.js';import bookingsRouter from './routes/bookings.js';
import { notFound, errorHandler } from './utils/errors.js';import { initIO } from './services/websocket.js';import { releaseExpiredHolds } from './services/seatHoldService.js';
dotenv.config();const app=express();app.use(express.json());app.use(morgan('dev'));app.use(cors({origin:process.env.CLIENT_ORIGIN?.split(',')||'*'}));
app.get('/',(req,res)=>res.json({ok:true,service:'gobus-backend'}));app.use('/api/trips',tripsRouter);app.use('/api/bookings',bookingsRouter);app.use(notFound);app.use(errorHandler);
const server=http.createServer(app);await initIO(server,process.env.CLIENT_ORIGIN);const PORT=process.env.PORT||5000;
connectDB(process.env.MONGO_URI).then(()=>{server.listen(PORT,()=>console.log(`Server on :${PORT}`));setInterval(releaseExpiredHolds,30000);});

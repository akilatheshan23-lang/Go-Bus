import mongoose from 'mongoose';
const bookingSchema=new mongoose.Schema({trip:{type:mongoose.Schema.Types.ObjectId,ref:'Trip'},seats:[{type:Number}],status:{type:String,enum:['draft','paid','cancelled','refunded'],default:'draft'},passenger:{name:String,nic:String,phone:String,email:String,special_needs:String},amount_base:Number,handling_fee:Number,total:Number},{timestamps:true});
export default mongoose.model('Booking',bookingSchema);

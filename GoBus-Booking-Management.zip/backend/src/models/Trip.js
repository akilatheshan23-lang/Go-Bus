import mongoose from 'mongoose';
const tripSchema=new mongoose.Schema({route:{from:String,to:String},date:String,departure_time:String,arrival_time:String,base_fare:{type:Number,default:1000},bus_type:{type:String,default:'AC_54'},template:{type:mongoose.Schema.Types.ObjectId,ref:'SeatTemplate'},isDemo:{type:Boolean,default:false}},{timestamps:true});
export default mongoose.model('Trip',tripSchema);

import mongoose from 'mongoose';
const seatHoldSchema=new mongoose.Schema({trip:{type:mongoose.Schema.Types.ObjectId,ref:'Trip'},seats:[{type:Number}],sessionId:String,expiresAt:Date,status:{type:String,enum:['held','released'],default:'held'}},{timestamps:true});
seatHoldSchema.index({expiresAt:1},{expireAfterSeconds:0,partialFilterExpression:{status:'released'}});
export default mongoose.model('SeatHold',seatHoldSchema);

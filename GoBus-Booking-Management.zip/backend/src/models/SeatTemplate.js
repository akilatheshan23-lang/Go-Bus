import mongoose from 'mongoose';
const seatSchema=new mongoose.Schema({number:{type:Number,required:true},col:{type:Number,required:true},row:{type:Number,required:true},type:{type:String,enum:['W','A','M'],default:'A'}});
const seatTemplateSchema=new mongoose.Schema({busType:{type:String,required:true},seats:[seatSchema],rows:{type:Number,required:true},columns:{type:Number,required:true},createdAt:{type:Date,default:Date.now}});
export default mongoose.model('SeatTemplate',seatTemplateSchema);

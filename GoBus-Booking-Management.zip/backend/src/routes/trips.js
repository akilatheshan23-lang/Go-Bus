import express from 'express';import { asyncHandler } from '../utils/asyncHandler.js';import { getSeats, getDemoTrip } from '../controllers/tripsController.js';
const router=express.Router();router.get('/demo',asyncHandler(getDemoTrip));router.get('/:tripId/seats',asyncHandler(getSeats));export default router;

import express from 'express';import { asyncHandler } from '../utils/asyncHandler.js';import { createBookingDraft, getBooking, updatePassenger } from '../controllers/bookingsController.js';
const router=express.Router();router.post('/',asyncHandler(createBookingDraft));router.get('/:id',asyncHandler(getBooking));router.patch('/:id/passenger',asyncHandler(updatePassenger));export default router;

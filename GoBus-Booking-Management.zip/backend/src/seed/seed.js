import dotenv from 'dotenv';import { connectDB } from '../config/db.js';import SeatTemplate from '../models/SeatTemplate.js';import Trip from '../models/Trip.js';
dotenv.config();
const build54SeatTemplate=()=>{const seats=[];let num=1;for(let r=0;r<13;r++){for(let c=0;c<4;c++){seats.push({number:num++,row:r,col:c,type:(c===0||c===3)?'W':'A'});}}seats.push({number:num++,row:13,col:1,type:'M'});seats.push({number:num++,row:13,col:2,type:'M'});return{rows:14,columns:4,seats};};
const run=async()=>{await connectDB(process.env.MONGO_URI);await SeatTemplate.deleteMany({busType:'AC_54'});await Trip.deleteMany({isDemo:true});
const {rows,columns,seats}=build54SeatTemplate();const template=await SeatTemplate.create({busType:'AC_54',rows,columns,seats});
const today=new Date();const dateStr=today.toISOString().slice(0,10);
const trip=await Trip.create({route:{from:'Colombo',to:'Kandy'},date:dateStr,departure_time:'08:00',arrival_time:'11:30',base_fare:Number(process.env.BASE_FARE)||1000,bus_type:'AC_54',template:template._id,isDemo:true});
console.log('Seeded template:',template._id);console.log('Seeded demo trip:',trip._id);process.exit(0);};run().catch(err=>{console.error(err);process.exit(1);});

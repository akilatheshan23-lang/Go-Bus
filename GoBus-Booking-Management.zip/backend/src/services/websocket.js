let ioInstance=null;
export const initIO=async(server,origin)=>{const {Server}=await import('socket.io');ioInstance=new Server(server,{cors:{origin,methods:['GET','POST','PATCH']}});return ioInstance;};
export const io=()=>ioInstance;

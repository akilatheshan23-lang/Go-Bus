export class HttpError extends Error{constructor(status,msg){super(msg);this.status=status;}}
export const notFound=(req,res,next)=>next(new HttpError(404,`Not Found: ${req.originalUrl}`));
export const errorHandler=(err,req,res,next)=>{const s=err.status||500;res.status(s).json({error:err.message||'Server Error'});};
